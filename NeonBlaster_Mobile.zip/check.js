
(() => {
"use strict";
const canvas=document.getElementById("game"),ctx=canvas.getContext("2d",{alpha:false});
let W=0,H=0,DPR=1;
const TAU=Math.PI*2, clamp=(v,a,b)=>Math.max(a,Math.min(b,v)), rand=(a,b)=>a+Math.random()*(b-a);
const input={keys:new Set(),mouseX:0,mouseY:0,shooting:false,mouseInside:false};
let secretComboLatched=false,coinComboLatched=false,shopComboLatched=false;
const player={x:0,y:0,r:16.25,hp:100,maxHp:100,speed:245,fire:0,rapid:0,invuln:0,dashCooldown:0,dashTime:0,dashVX:0,dashVY:0};
let bullets=[],foes=[],enemyShots=[],particles=[],drops=[],boss=null,bossLasers=[],bossTelegraphs=[];
let score=0,wave=1,time=0,gameOver=false,spawn=0,shake=0,last=performance.now(),aimAngle=0;
let coins=0, paused=false, shopOpen=false, waveSpawned=0, enemiesToSpawn=0, bossPending=false;
let bossWave=false, bossNumber=0, bossStage="none", shopBeforeBoss=false, waveBanner="", waveBannerTimer=0;
let potionPity=0, restOpen=false, bossKills=0, shopPending=false;
const GAME_VERSION="BETA 0.5";
let currentWeapon="ak47", weaponPower=1, upgradeLevels={damage:0,rate:0,speed:0,maxhp:0,magnet:0};
const rarities=[{name:"ОБЫЧНЫЙ",color:"#c6d0d8",weight:58,mult:1,unlock:0},{name:"РЕДКИЙ",color:"#42a5ff",weight:27,mult:1.55,unlock:0},{name:"ЭПИЧЕСКИЙ",color:"#bd68ff",weight:10,mult:2.3,unlock:2},{name:"ЛЕГЕНДАРНЫЙ",color:"#ffb52e",weight:4,mult:3.4,unlock:3},{name:"МИФИЧЕСКИЙ",color:"#ff4f9a",weight:1.5,mult:4.8,unlock:4},{name:"СЕКРЕТНЫЙ",color:"#4dffe0",weight:.45,mult:7,unlock:5},{name:"ХАОТИЧЕСКИЙ",color:"#ff4d4d",weight:.12,mult:10,unlock:10}];
let shopOffers=[];
const weapons={
 ak47:{name:"AK-47",cost:0,damage:22,rate:.19,pellets:1,spread:.025,speed:820,desc:"Пиксельный автомат · стартовое оружие"},
 glock:{name:"GLOCK",cost:0,damage:22,rate:.19,pellets:1,spread:.025,speed:820,desc:"Надёжный стартовый пистолет"},
 smg:{name:"VOLT SMG",cost:90,damage:13,rate:.075,pellets:1,spread:.07,speed:790,desc:"Очень высокая скорострельность"},
 shotgun:{name:"NOVA SHOTGUN",cost:150,damage:15,rate:.48,pellets:6,spread:.34,speed:700,desc:"Шесть энергетических зарядов"},
 rifle:{name:"PULSE RIFLE",cost:230,damage:48,rate:.32,pellets:1,spread:.012,speed:1050,desc:"Мощные точные выстрелы"},
 arc:{name:"ARC CANNON",cost:340,damage:28,rate:.22,pellets:3,spread:.18,speed:900,desc:"Тройной электрический залп"}
};
let best=0,bestTime=0;
try{best=+(localStorage.nbScore||0);bestTime=+(localStorage.nbTime||0)}catch(e){}
let audioCtx=null;
function sound(f=440,d=.06,type="square",vol=.025,slide=0){
 try{audioCtx ||= new (window.AudioContext||window.webkitAudioContext)();if(audioCtx.state==="suspended")audioCtx.resume();
 const o=audioCtx.createOscillator(),g=audioCtx.createGain(),t=audioCtx.currentTime;
 o.type=type;o.frequency.setValueAtTime(f,t);if(slide)o.frequency.exponentialRampToValueAtTime(Math.max(25,f+slide),t+d);
 g.gain.setValueAtTime(vol,t);g.gain.exponentialRampToValueAtTime(.001,t+d);o.connect(g).connect(audioCtx.destination);o.start(t);o.stop(t+d);
 }catch(e){}
}
function resize(){DPR=Math.min(devicePixelRatio||1,2);W=innerWidth;H=innerHeight;canvas.width=Math.floor(W*DPR);canvas.height=Math.floor(H*DPR);ctx.setTransform(DPR,0,0,DPR,0,0);player.x=clamp(player.x||W/2,player.r,W-player.r);player.y=clamp(player.y||H/2,player.r,H-player.r)}
addEventListener("resize",resize);resize();
function updateMouse(e){const r=canvas.getBoundingClientRect();input.mouseX=e.clientX-r.left;input.mouseY=e.clientY-r.top;input.mouseInside=true}
function keyName(e){
 if(e.code && e.code.startsWith("Key"))return e.code.slice(3).toLowerCase();
 if(e.code && e.code.startsWith("Arrow"))return e.code.toLowerCase();
 if(e.code==="Escape")return "escape";
 if(e.code==="Space")return " ";
 return e.key.toLowerCase();
}
addEventListener("keydown",e=>{
 const k=keyName(e);
 if(["w","a","s","d","arrowup","arrowdown","arrowleft","arrowright"," ","shift"].includes(k))e.preventDefault();
 if((k==="shift"||k===" ")&&!e.repeat&&!gameOver&&!paused&&!shopOpen&&!restOpen&&player.dashCooldown<=0){
  const dx=(input.keys.has("d")||input.keys.has("arrowright")?1:0)-(input.keys.has("a")||input.keys.has("arrowleft")?1:0);
  const dy=(input.keys.has("s")||input.keys.has("arrowdown")?1:0)-(input.keys.has("w")||input.keys.has("arrowup")?1:0);
  const a=(dx||dy)?Math.atan2(dy,dx):aimAngle;
  player.dashVX=Math.cos(a);player.dashVY=Math.sin(a);player.dashTime=.17;player.dashCooldown=.7;player.invuln=Math.max(player.invuln,.22);
  for(let i=0;i<9;i++)burst(player.x-player.dashVX*i*5,player.y-player.dashVY*i*5,"#64eaff",2,45);
  sound(520,.09,"triangle",.035,180);
 }
 input.keys.add(k);
 if(input.keys.has("f")&&input.keys.has("g")&&input.keys.has("h")&&!secretComboLatched){
  secretComboLatched=true;
  if(!gameOver){
   wave=Math.max(5,Math.ceil(wave/5)*5);
   foes=[];enemyShots=[];bullets=[];bossLasers=[];bossTelegraphs=[];drops=[];
   bossWave=true;bossNumber=Math.floor(wave/5);bossStage="boss";
   enemiesToSpawn=0;waveSpawned=0;spawn=0;boss=null;
   player.maxHp=10000;player.hp=10000;player.invuln=1.2;
   paused=false;shopOpen=false;restOpen=false;shopBeforeBoss=false;shopPending=false;
   document.getElementById("shop").style.display="none";document.getElementById("rest").style.display="none";
   document.getElementById("pauseBtn").textContent="PAUSE [P]";
   spawnBoss();showWaveBanner("SECRET ACCESS · BOSS WAVE · 10000 HP");
   sound(880,.35,"sine",.06);last=performance.now();
  }
 }
 if(input.keys.has("m")&&input.keys.has("n")&&input.keys.has("t")&&!coinComboLatched){
  coinComboLatched=true;coins+=50000;showWaveBanner("SECRET BONUS · +50000 COINS");
  burst(player.x,player.y,"#ffe45c",36,320);sound(1040,.4,"sine",.07,420);
 }
 if(input.keys.has("m")&&input.keys.has("g")&&input.keys.has("z")&&input.keys.has("n")&&!shopComboLatched){
  shopComboLatched=true;
  if(!gameOver&&!shopOpen&&!restOpen){
   openShop();showWaveBanner("SECRET ACCESS · NEON ARMORY");
   sound(760,.28,"triangle",.06,260);
  }
 }
 if(k==="r"&&gameOver)restart();
 if(k==="p"||k==="escape")togglePause();
});
addEventListener("keyup",e=>{input.keys.delete(keyName(e));if(!(input.keys.has("f")&&input.keys.has("g")&&input.keys.has("h")))secretComboLatched=false;if(!(input.keys.has("m")&&input.keys.has("n")&&input.keys.has("t")))coinComboLatched=false;if(!(input.keys.has("m")&&input.keys.has("g")&&input.keys.has("z")&&input.keys.has("n")))shopComboLatched=false});
addEventListener("blur",()=>{input.keys.clear();input.shooting=false});
canvas.addEventListener("mousemove",updateMouse);
canvas.addEventListener("mouseenter",e=>{updateMouse(e);input.mouseInside=true});
canvas.addEventListener("mouseleave",()=>{input.mouseInside=false;input.shooting=false});
canvas.addEventListener("mousedown",e=>{if(e.button!==0)return;updateMouse(e);sound(1,.001);if(gameOver){restart();return}input.shooting=true});
addEventListener("mouseup",e=>{if(e.button===0)input.shooting=false});
canvas.addEventListener("contextmenu",e=>e.preventDefault());
function showWaveBanner(text){
 waveBanner=text;waveBannerTimer=2.6;
}
function beginWave(){
 bossWave=false;bossStage="none";
 enemiesToSpawn=5+wave*2;waveSpawned=0;
 spawn=.8;showWaveBanner("WAVE "+wave);
}
function beginBossWave(){
 bossWave=true;bossNumber=Math.floor(wave/5);bossStage="minions";
 enemiesToSpawn=Math.max(4,4+bossNumber*2);waveSpawned=0;spawn=.7;
 boss=null;showWaveBanner("BOSS WAVE "+bossNumber+" · CLEAR THE ENEMIES");
 sound(75,.7,"sawtooth",.07);
}
function completeWave(){
 if(bossWave){
  bossWave=false;bossStage="none";boss=null;bossKills++;
  restOpen=true;paused=true;input.shooting=false;document.getElementById("rest").style.display="flex";
 } else if(wave%5===0){
  shopBeforeBoss=true;shopPending=true;
 } else {
  wave++;beginWave();sound(620,.16,"sine",.05);
 }
}
function rollRarity(){
 const available=rarities.filter(r=>bossKills>=r.unlock);const total=available.reduce((a,r)=>a+r.weight,0);let n=Math.random()*total;
 for(const r of available){n-=r.weight;if(n<=0)return r}return available[0];
}
const upgrades=[
 {id:"damage",name:"УРОН +8%",desc:"Увеличивает урон оружия",base:65,apply:p=>upgradeLevels.damage+=p},
 {id:"rate",name:"СКОРОСТРЕЛЬНОСТЬ +7%",desc:"Стреляешь чаще",base:75,apply:p=>upgradeLevels.rate+=p},
 {id:"speed",name:"СКОРОСТЬ +8%",desc:"Быстрее передвижение",base:60,apply:p=>{upgradeLevels.speed+=p;player.speed*=Math.pow(1.08,p)}},
 {id:"maxhp",name:"МАКС. HP +15",desc:"Увеличивает запас здоровья и лечит",base:85,apply:p=>{upgradeLevels.maxhp+=p;player.maxHp+=15*p;player.hp=Math.min(player.maxHp,player.hp+15*p)}},
 {id:"magnet",name:"МАГНИТ МОНЕТ",desc:"Увеличивает радиус сбора предметов",base:55,apply:p=>upgradeLevels.magnet+=p}
];
function openShop(){
 shopOpen=true;paused=true;input.shooting=false;
 const panel=document.getElementById("shop"),items=document.getElementById("shopItems");
 document.getElementById("shopCoins").textContent="МОНЕТЫ: "+coins+" · ПОСЛЕ ВОЛНЫ "+wave;
 items.innerHTML="";shopOffers=[];
 const catalog=[...Object.entries(weapons).filter(([id])=>id!=="glock"&&id!==currentWeapon).map(([id,w])=>({id:"weapon_"+id,name:w.name,desc:w.desc,base:w.cost,kind:"weapon",weapon:id})),...upgrades.map(u=>({...u,kind:"upgrade"}))];
 const offerCount=Math.min(4,catalog.length),discountedCount=Math.ceil(offerCount*.5);
 for(let i=0;i<offerCount;i++){
  const idx=Math.floor(Math.random()*catalog.length),item=catalog.splice(idx,1)[0],rarity=rollRarity();
  const tier=rarities.indexOf(rarity);
  // Two lower-priced and two premium offers. Prices never depend on the player's
  // current wallet, and rarity adds a controlled premium instead of exploding.
  const affordable=i<discountedCount;
  const baseValue=item.base>0?item.base:70;
  const waveBonus=Math.min(30,Math.max(0,wave-1)*2);
  const rawCost=affordable
    ? baseValue*.30+tier*7+waveBonus*.25
    : baseValue*.48+tier*13+waveBonus;
  const cost=Math.round(clamp(rawCost,affordable?35:80,affordable?75:180)/5)*5;
  const offer={item,rarity,cost,affordable,purchased:false,button:null};shopOffers.push(offer);
  const row=document.createElement("div");row.className="shopItem";
  const info=document.createElement("div");info.innerHTML="<b>"+item.name+"</b><br><small>"+item.desc+"</small><br><small style='color:"+rarity.color+"'>◆ "+rarity.name+" · x"+rarity.mult+(affordable?" · СПЕЦЦЕНА":"")+"</small>";
  const btn=document.createElement("button");offer.button=btn;
  btn.onclick=()=>{if(offer.purchased||coins<offer.cost)return;coins-=offer.cost;offer.purchased=true;const tier=rarities.indexOf(rarity),power=1+tier*.35;if(item.kind==="weapon"){currentWeapon=item.weapon;weaponPower*=power}else item.apply(power);renderShop();sound(820,.12,"sine",.05)};
  row.append(info,btn);items.append(row);
 }
 renderShop();panel.style.display="flex";
}
function renderShop(){
 document.getElementById("shopCoins").textContent="МОНЕТЫ: "+coins+" · ТЕКУЩЕЕ ОРУЖИЕ: "+weapons[currentWeapon].name;
 for(const offer of shopOffers){if(!offer.button)continue;offer.button.textContent=offer.purchased?"КУПЛЕНО":"КУПИТЬ · "+offer.cost+" монет";offer.button.disabled=offer.purchased||coins<offer.cost}
}
document.getElementById("restYes").addEventListener("click",()=>{
 document.getElementById("rest").style.display="none";restOpen=false;paused=false;wave++;beginWave();last=performance.now();sound(620,.16,"sine",.05);
});
document.getElementById("restNo").addEventListener("click",()=>{
 document.getElementById("rest").style.display="none";restOpen=false;paused=false;endGame();last=performance.now();
});
document.getElementById("continueShop").addEventListener("click",()=>{
 document.getElementById("shop").style.display="none";shopOpen=false;paused=false;
 if(shopBeforeBoss){shopBeforeBoss=false;beginBossWave()}else{wave++;beginWave()}
 last=performance.now()
});
function togglePause(){if(gameOver||shopOpen||restOpen)return;paused=!paused;document.getElementById("pauseBtn").textContent=paused?"RESUME [P]":"PAUSE [P]";last=performance.now()}
document.getElementById("pauseBtn").addEventListener("click",togglePause);
function spawnEnemy(){
 const side=Math.floor(Math.random()*4),m=30;
 let x=side===1?W+m:side===3?-m:rand(0,W),y=side===0?-m:side===2?H+m:rand(0,H);
 const lv=Math.min(wave,30),roll=Math.random();
 // Red enemies first; yellow unlock after boss 1; purple after boss 2.
 let type="basic";
 if(bossNumber>=2 && roll<.22)type="purple";
 else if(bossNumber>=1 && roll<.38)type="fast";
 const data=type==="basic"
  ?{r:15,hp:34+lv*8,speed:82+lv*2.8,dmg:34+lv*2.1,color:"#ff475d",points:10,shot:rand(.3,.7)}
  :type==="fast"
  ?{r:10,hp:24+lv*5,speed:190+lv*4,dmg:23+lv*1.5,color:"#ffe13b",points:15,shot:rand(.8,1.25),dash:rand(1.4,2.4)}
  :{r:19,hp:(34+lv*8)*3,speed:25+lv*.6,dmg:58+lv*3.2,color:"#b45cff",points:25,shot:rand(1.0,1.5),burst:0};
 foes.push({x,y,...data,maxHp:data.hp,type,attack:rand(.3,.7)});
}
function spawnBoss(){
 const hp=(1850+wave*270)*.75;
 boss={x:W/2,y:Math.max(110,H*.22),r:44,baseR:44,hp,maxHp:hp,baseSpeed:78+wave*.7,speed:78+wave*.7,shot:1.05,teleportTimer:rand(5,10),laserCooldown:1.4,radialCooldown:rand(4.5,6.5),moveTimer:0,moveAngle:rand(0,TAU),stage:1,volleyTimer:0,volleyShots:0,volleyGap:0,laserMode:"radial",sweep:null,dash:null,specialTimer:rand(3.5,5.5),color:"#ff26d8"};
}
function burst(x,y,color,n=10,power=230){for(let i=0;i<n;i++){const a=rand(0,TAU),s=rand(power*.25,power);particles.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,life:rand(.25,.7),max:.7,r:rand(2,4),color})}}
function hurt(amount){if(player.invuln>0)return;player.hp-=amount;player.invuln=.38;shake=Math.min(14,shake+5);sound(120,.12,"sawtooth",.05,-55);burst(player.x,player.y,"#ff355e",7,170);if(player.hp<=0)endGame()}
function endGame(){gameOver=true;player.hp=0;const t=time;if(score>best){best=score;try{localStorage.nbScore=best}catch(e){}}if(t>bestTime){bestTime=t;try{localStorage.nbTime=bestTime}catch(e){}}sound(95,.6,"sawtooth",.07,-60)}
function resetInput(){input.keys.clear();input.shooting=false;input.mouseInside=false;}
function restart(){bullets=[];foes=[];enemyShots=[];particles=[];drops=[];boss=null;bossLasers=[];bossTelegraphs=[];potionPity=0;bossKills=0;restOpen=false;document.getElementById("rest").style.display="none";score=0;coins=0;wave=1;bossWave=false;bossNumber=0;bossStage="none";shopBeforeBoss=false;shopPending=false;waveBanner="";waveBannerTimer=0;time=0;spawn=0;shake=0;gameOver=false;paused=false;shopOpen=false;currentWeapon="ak47";weaponPower=1;upgradeLevels={damage:0,rate:0,speed:0,maxhp:0,magnet:0};document.getElementById("shop").style.display="none";document.getElementById("pauseBtn").textContent="PAUSE [P]";Object.assign(player,{x:W/2,y:H/2,r:16.25,hp:100,maxHp:100,speed:245,rapid:0,fire:0,invuln:0,dashCooldown:0,dashTime:0,dashVX:0,dashVY:0});aimAngle=0;playerRunTime=0;playerFacing=1;resetInput();beginWave();last=performance.now()}
function update(dt){
 if(gameOver||paused)return;time+=dt;
 const keys=input.keys;
 const mx=(keys.has("d")||keys.has("arrowright")?1:0)-(keys.has("a")||keys.has("arrowleft")?1:0);
 const my=(keys.has("s")||keys.has("arrowdown")?1:0)-(keys.has("w")||keys.has("arrowup")?1:0);
 const ml=Math.hypot(mx,my)||1;
 // Player movement is never slowed by the boss's phase-two laser sweep.
 player.dashCooldown=Math.max(0,player.dashCooldown-dt);
 if(player.dashTime>0){
  const dashSpeed=player.speed*3.8;
  player.x=clamp(player.x+player.dashVX*dashSpeed*dt,player.r,W-player.r);
  player.y=clamp(player.y+player.dashVY*dashSpeed*dt,player.r,H-player.r);
  player.dashTime=Math.max(0,player.dashTime-dt);
 }else{
  player.x=clamp(player.x+mx/ml*player.speed*dt,player.r,W-player.r);
  player.y=clamp(player.y+my/ml*player.speed*dt,player.r,H-player.r);
 }
 const moving=player.dashTime>0||mx!==0||my!==0;
 if(moving)playerRunTime+=dt;else playerRunTime=0;
 if(mx!==0)playerFacing=mx>0?1:-1;
 player.invuln=Math.max(0,player.invuln-dt);player.rapid=Math.max(0,player.rapid-dt);
 if(input.mouseInside)aimAngle=Math.atan2(input.mouseY-player.y,input.mouseX-player.x);
 player.fire-=dt;const weapon=weapons[currentWeapon];if(input.shooting&&player.fire<=0){player.fire=(player.rapid>0?weapon.rate*.55:weapon.rate)*Math.pow(.93,upgradeLevels.rate)*Math.pow(.96,Math.max(0,weaponPower-1));for(let n=0;n<weapon.pellets;n++){const a=aimAngle+rand(-weapon.spread,weapon.spread);const pose=getWeaponPose(player.x,player.y,a);bullets.push({x:pose.muzzleX,y:pose.muzzleY,vx:Math.cos(a)*weapon.speed,vy:Math.sin(a)*weapon.speed,life:1.25,r:weapon.pellets>1?3:4,dmg:weapon.damage*weaponPower*Math.pow(1.08,upgradeLevels.damage)});}sound(weapon.pellets>1?180:310,.035,"square",.012)}
 if(enemiesToSpawn>0){
  spawn-=dt;
  if(spawn<=0){spawn=Math.max(.28,1.0-wave*.025);spawnEnemy();enemiesToSpawn--;waveSpawned++}
 }
 for(let i=bullets.length-1;i>=0;i--){const b=bullets[i];b.x+=b.vx*dt;b.y+=b.vy*dt;b.life-=dt;if(b.life<=0||b.x<-20||b.x>W+20||b.y<-20||b.y>H+20){bullets.splice(i,1);continue}
 let hit=false;for(let k=foes.length-1;k>=0;k--){const e=foes[k];if(Math.hypot(e.x-b.x,e.y-b.y)<e.r+b.r){e.hp-=e.type==="fast"?10:b.dmg;hit=true;if(e.hp<=0){score+=e.points;
  drops.push({x:e.x,y:e.y,r:9,type:"coin",life:18,value:e.type==="purple"?3:e.type==="fast"?2:1});
  const potionChance=Math.min(5+potionPity*3,80);if(Math.random()*100<potionChance){drops.push({x:e.x+rand(-8,8),y:e.y+rand(-8,8),r:10,type:"potion",life:18,value:25});potionPity=0}else potionPity++;
  burst(e.x,e.y,e.color,12,240);foes.splice(k,1)}break}}
 if(!hit&&boss&&Math.hypot(boss.x-b.x,boss.y-b.y)<boss.r+b.r){boss.hp-=b.dmg;hit=true;if(boss.hp<=0){const deadX=boss.x,deadY=boss.y;score+=500;burst(deadX,deadY,"#ff26d8",55,430);boss=null;bossLasers=[];bossTelegraphs=[];enemyShots=[];shake=22;sound(160,.9,"sine",.08,-120);const reward=Math.floor(rand(30,71));for(let c=0;c<reward;c++){const a=rand(0,TAU),d=rand(8,78);drops.push({x:deadX+Math.cos(a)*d,y:deadY+Math.sin(a)*d,r:7,type:"coin",life:30,value:1})}completeWave();}}
 if(hit)bullets.splice(i,1)}
 for(let i=foes.length-1;i>=0;i--){
  const e=foes[i],dx=player.x-e.x,dy=player.y-e.y,d=Math.hypot(dx,dy)||1;
  let moveSpeed=e.speed;
  if(e.type==="fast"){
   e.dashTimer=(e.dashTimer??rand(.8,1.5))-dt;
   if(e.dashTimer<=0){e.dashTimer=rand(1.8,2.6);e.dashActive=.32}
   if(e.dashActive>0){moveSpeed*=2.15;e.dashActive-=dt}
  }
  e.x+=dx/d*moveSpeed*dt;e.y+=dy/d*moveSpeed*dt;
  e.attack-=dt;
  if(e.attack<=0){
   e.attack=e.type==="basic"?rand(.3,.7):e.type==="fast"?rand(.8,1.25):rand(1.0,1.5);
   const a=Math.atan2(dy,dx),speed=e.type==="fast"?390:e.type==="purple"?260:310;
   if(e.type==="purple"){
    for(let n=-1;n<=1;n++){const an=a+n*.22;enemyShots.push({x:e.x,y:e.y,vx:Math.cos(an)*speed,vy:Math.sin(an)*speed,r:8,life:4,dmg:32})}
   } else {
    enemyShots.push({x:e.x,y:e.y,vx:Math.cos(a)*speed,vy:Math.sin(a)*speed,r:e.type==="fast"?5:6,life:4,dmg:e.type==="fast"?16:20})
   }
  }
  if(d<e.r+player.r){hurt(e.dmg*dt*2.5);e.x-=dx/d*70*dt;e.y-=dy/d*70*dt}
 }
 if(boss){
  // Four escalating phases, based on remaining health.
  const ratio=boss.hp/boss.maxHp;
  const nextStage=ratio<=.20?4:ratio<=.45?3:ratio<=.72?2:1;
  if(nextStage!==boss.stage){
   boss.stage=nextStage;boss.shot=Math.min(boss.shot,.35);boss.color=nextStage===4?"#ff3b63":nextStage===3?"#a64dff":nextStage===2?"#ff8a35":"#ff26d8";
   if(nextStage===3)boss.r=boss.baseR*.5;
   if(nextStage===4){boss.dash=null;boss.teleportTimer=rand(2.5,6.5)}
   showWaveBanner("BOSS · PHASE "+nextStage);burst(boss.x,boss.y,boss.color,24,280);sound(165,.28,"triangle",.025);
  }
  const stage=boss.stage;
  // Stationary radial laser burst is available on every boss stage.
  // The boss remains fixed from the warning telegraph until all radial beams vanish.
  const stationaryLaserLock=bossTelegraphs.some(t=>t.mode==="strike")||bossLasers.some(l=>l.mode==="strike");
  // Smooth evasive movement; later stages may blink during rotating fans, but never during radial bursts.
  boss.moveTimer-=dt;
  if(boss.moveTimer<=0){boss.moveTimer=rand(.7,1.35);boss.moveAngle=Math.atan2(boss.y-player.y,boss.x-player.x)+rand(-1.15,1.15)}
  const moveSpeed=boss.baseSpeed*(stage>=3?1.2:stage===2?1.1:1);
  if(!boss.dash&&!stationaryLaserLock){boss.x+=Math.cos(boss.moveAngle)*moveSpeed*dt;boss.y+=Math.sin(boss.moveAngle)*moveSpeed*dt;
   if(boss.x<boss.r+18||boss.x>W-boss.r-18)boss.moveAngle=Math.PI-boss.moveAngle;
   if(boss.y<boss.r+85||boss.y>H-boss.r-25)boss.moveAngle=-boss.moveAngle;
   boss.x=clamp(boss.x,boss.r+18,W-boss.r-18);boss.y=clamp(boss.y,boss.r+85,H-boss.r-25);
  }
  if(!(stage===2&&(boss.sweep||bossLasers.some(l=>l.dir))))boss.teleportTimer-=dt;
  if(boss.teleportTimer<=0&&!boss.dash&&!stationaryLaserLock&&!(stage===2&&(boss.sweep||bossLasers.some(l=>l.dir)))){
   let tx,ty,tries=0;do{tx=rand(W*.12,W*.88);ty=rand(H*.16,H*.62);tries++}while(Math.hypot(tx-player.x,ty-player.y)<Math.max(170,boss.r+player.r+90)&&tries<30);
   burst(boss.x,boss.y,boss.color,16,240);boss.x=tx;boss.y=ty;boss.teleportTimer=stage>=3?rand(2.5,6.5):rand(5,10);burst(boss.x,boss.y,boss.color,16,240);sound(360,.12,"sine",.025);
  }
  // Phase 4: multi-bounce aimed charge. It cannot begin during another attack.
  if(stage===4){
   if(!boss.dash&&boss.dashCooldown!==undefined)boss.dashCooldown-=dt;
   if(!boss.dash&&(!boss.dashCooldown||boss.dashCooldown<=0)){
    const a=Math.atan2(player.y-boss.y,player.x-boss.x);boss.dash={vx:Math.cos(a)*620,vy:Math.sin(a)*620,left:Math.floor(rand(3,7)),time:0};boss.dashCooldown=rand(4.5,6.5);boss.teleportTimer=999;
   }
   if(boss.dash){const d=boss.dash;boss.x+=d.vx*dt;boss.y+=d.vy*dt;d.time+=dt;
    const wall=boss.x<boss.r||boss.x>W-boss.r||boss.y<boss.r+70||boss.y>H-boss.r;
    if(wall){boss.x=clamp(boss.x,boss.r,W-boss.r);boss.y=clamp(boss.y,boss.r+70,H-boss.r);d.left--;if(d.left<=0){boss.dash=null;boss.teleportTimer=rand(2.5,6.5)}else{const a=Math.atan2(player.y-boss.y,player.x-boss.x);d.vx=Math.cos(a)*640;d.vy=Math.sin(a)*640;burst(boss.x,boss.y,"#ff3b63",12,220);}}
    if(Math.hypot(player.x-boss.x,player.y-boss.y)<boss.r+player.r)hurt(34);
   }
  }
  // Every phase retains aimed volleys; later phases add more lanes, speed and damage.
  if(stage>=1){
   if(boss.volleyShots>0){boss.volleyGap-=dt;if(boss.volleyGap<=0){boss.volleyGap=.05;boss.volleyShots--;const a=Math.atan2(player.y-boss.y,player.x-boss.x),px=-Math.sin(a),py=Math.cos(a),speed=stage>=3?500:stage===2?440:370;
    const spread=stage>=4?4:stage===3?3:stage===2?3:2;
    for(let lane=-spread;lane<=spread;lane++){const offset=lane*player.r/2;enemyShots.push({x:boss.x+px*offset,y:boss.y+py*offset,vx:Math.cos(a)*speed,vy:Math.sin(a)*speed,r:stage>=3?7:stage===2?6.5:6,life:4,dmg:stage>=3?24:stage===2?21:15})}
   }}else{boss.shot-=dt;if(boss.shot<=0){boss.volleyShots=stage>=4?14:stage===3?13:stage===2?12:10;boss.volleyGap=0;boss.shot=stage>=3?rand(1.15,1.55):stage===2?rand(1.4,1.9):rand(2.1,2.7)}}
  }
  // Phase 3+: periodic expanding radial shock volleys force the player to reposition.
  if(stage>=3){boss.specialTimer-=dt;if(boss.specialTimer<=0){const n=stage===4?20:14;for(let k=0;k<n;k++){const a=k*TAU/n;const sp=stage===4?330:270;enemyShots.push({x:boss.x,y:boss.y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,r:stage===4?7:6,life:3.5,dmg:stage===4?22:17})}burst(boss.x,boss.y,boss.color,30,300);boss.specialTimer=stage===4?rand(3.2,4.2):rand(4.2,5.2)}}
  // Stage 1 keeps its radial laser pattern. From stage 2 onward the boss
  // alternates rotating fans with a stationary radial burst, so both attacks remain in its kit.
  boss.laserCooldown-=dt;
  if(stage===1){
   if(boss.laserCooldown<=0&&!stationaryLaserLock){
    const count=12;
    for(let k=0;k<count;k++){const a=k*TAU/count;bossTelegraphs.push({x:boss.x,y:boss.y,angle:a,length:Math.hypot(W,H),timer:1.0,width:22,mode:"strike",followBoss:true})}
    boss.laserCooldown=rand(2.6,3.2);
   }
  }else{
   // Rotating fan: same 2-second duration and 45% player-relative angular speed on stages 2–4.
   if(boss.laserCooldown<=0&&!boss.sweep&&!stationaryLaserLock&&!bossLasers.some(l=>l.dir)){
    const clockwise=Math.random()<.5?1:-1;
    const a=rand(0,TAU);
    const duration=2;
    const angularSpeed=player.speed*.45/260;
    boss.sweep={angle:a,dir:clockwise,travel:0,duration,angularSpeed};
    bossTelegraphs.push({x:boss.x,y:boss.y,angle:a,length:Math.hypot(W,H),timer:1.0,width:26,mode:"sweep",dir:clockwise,angularSpeed,duration,rayCount:7,followBoss:true});
    boss.laserCooldown=stage===2?rand(4.0,5.0):stage===3?rand(3.5,4.5):rand(3.0,4.0);
   }
   // Additional radial burst: boss stops, telegraphs evenly spaced beams, then fires them around itself.
   boss.radialCooldown-=dt;
   if(boss.radialCooldown<=0&&!boss.sweep&&!bossLasers.some(l=>l.dir)&&!stationaryLaserLock){
    boss.dash=null; // cancel a stage-four charge so the stationary attack is genuinely stationary
    const count=stage===2?12:stage===3?14:16;
    for(let k=0;k<count;k++){
     const a=k*TAU/count;
     bossTelegraphs.push({x:boss.x,y:boss.y,angle:a,length:Math.hypot(W,H),timer:.85,width:stage>=4?28:24,mode:"strike",followBoss:true});
    }
    boss.radialCooldown=stage===2?rand(7.0,9.0):stage===3?rand(6.0,8.0):rand(5.0,7.0);
   }
  }
  if(boss.sweep){boss.sweep.travel+=dt;boss.sweep.angle+=boss.sweep.dir*boss.sweep.angularSpeed*dt;if(boss.sweep.travel>=boss.sweep.duration)boss.sweep=null;}
  if(Math.hypot(player.x-boss.x,player.y-boss.y)<boss.r+player.r)hurt(28*dt);
 }
 // Resolve laser telegraphs, then spawn actual damaging beams.
 for(let i=bossTelegraphs.length-1;i>=0;i--){
  const t=bossTelegraphs[i];if(t.followBoss&&boss){t.x=boss.x;t.y=boss.y}t.timer-=dt;
  if(t.timer<=0){
   if(t.mode==="sweep"){
    const count=t.rayCount||7;
    const duration=t.duration||2;
    const angularSpeed=t.angularSpeed||(player.speed*.45/260);
    for(let k=0;k<count;k++){
     const angle=t.angle+k*TAU/count;
     bossLasers.push({x:t.x,y:t.y,angle,length:t.length,life:duration,maxLife:duration,width:30,hit:false,dmg:27,dir:t.dir||0,angularSpeed,sweepAge:0,followBoss:true});
    }
   }else bossLasers.push({x:t.x,y:t.y,angle:t.angle,length:t.length,life:.42,maxLife:.42,width:t.width,hit:false,dmg:27,dir:0,sweepAge:0,mode:"strike",followBoss:!!t.followBoss});
   bossTelegraphs.splice(i,1);sound(145,.16,"sine",.018);
  }
 }
 for(let i=bossLasers.length-1;i>=0;i--){
  const l=bossLasers[i];if(l.followBoss&&boss){l.x=boss.x;l.y=boss.y}l.life-=dt;if(l.dir){l.angle+=l.dir*(l.angularSpeed||Math.PI/l.maxLife)*dt;l.sweepAge+=dt}
  const ex=l.x+Math.cos(l.angle)*l.length,ey=l.y+Math.sin(l.angle)*l.length;
  const px=player.x-l.x,py=player.y-l.y;
  const along=clamp(px*Math.cos(l.angle)+py*Math.sin(l.angle),0,l.length);
  const nearX=l.x+Math.cos(l.angle)*along,nearY=l.y+Math.sin(l.angle)*along;
  if(!l.hit&&Math.hypot(player.x-nearX,player.y-nearY)<player.r+l.width/2){hurt(l.dmg);l.hit=true}
  if(l.life<=0)bossLasers.splice(i,1);
 }
 for(let i=enemyShots.length-1;i>=0;i--){const b=enemyShots[i];b.x+=b.vx*dt;b.y+=b.vy*dt;b.life-=dt;if(b.life<=0||b.x<-20||b.x>W+20||b.y<-20||b.y>H+20){enemyShots.splice(i,1);continue}if(Math.hypot(b.x-player.x,b.y-player.y)<b.r+player.r){hurt(b.dmg);enemyShots.splice(i,1)}}
 for(let i=drops.length-1;i>=0;i--){
  const p=drops[i];p.life-=dt;
  const dx=player.x-p.x,dy=player.y-p.y,d=Math.hypot(dx,dy)||1;
  if(d<135+upgradeLevels.magnet*55){p.x+=dx/d*300*dt;p.y+=dy/d*300*dt}
  if(d<p.r+player.r){
   if(p.type==="potion"){const before=player.hp;player.hp=Math.min(player.maxHp,player.hp+25);burst(p.x,p.y,"#55ff9a",12,160);sound(760,.14,"sine",.05);if(player.hp>before){}}
   else{coins+=p.value||1;burst(p.x,p.y,"#ffe45c",8,130);sound(650,.08,"sine",.04)}
   drops.splice(i,1)
  } else if(p.life<=0)drops.splice(i,1)
 }
 // At the fifth-wave break, vacuum every remaining coin before showing the shop.
 if(shopPending){
  for(let i=drops.length-1;i>=0;i--){const p=drops[i];if(p.type==="coin"){coins+=p.value||1;burst(p.x,p.y,"#ffe45c",8,130);drops.splice(i,1)}}
  shopPending=false;openShop();
 }
 // Advance only when every enemy in the current wave has been defeated.
 if(bossWave && bossStage==="minions" && enemiesToSpawn===0 && foes.length===0){
  bossStage="boss";spawnBoss();showWaveBanner("BOSS "+bossNumber+" · INCOMING");sound(75,.7,"sawtooth",.07);
 }
 if(!restOpen&&!shopOpen&&!bossWave && enemiesToSpawn===0 && foes.length===0 && !boss)completeWave();
 if(bossWave && bossStage==="boss" && !boss && foes.length===0)completeWave();
 waveBannerTimer=Math.max(0,waveBannerTimer-dt);
 for(let i=particles.length-1;i>=0;i--){const p=particles[i];p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=Math.pow(.08,dt);p.vy*=Math.pow(.08,dt);p.life-=dt;if(p.life<=0)particles.splice(i,1)}
 shake=Math.max(0,shake-28*dt);
}
const spriteImages={};
const spriteFiles=["pizza.png","token_f.png","idle.png","run_left_1.png","run_left_2.png","run_left_3.png","run_right_1.png","run_right_2.png","run_right_3.png","ak47.png","bullet_pencil.png"];
for(const file of spriteFiles){const img=new Image();img.src="assets/"+file;spriteImages[file]=img}
let playerRunTime=0,playerFacing=1;
function getWeaponPose(x,y,angle){
 // The grip pivot is anchored to the character's upper torso/forward hand.
 // Keeping the pivot in player-local space makes the rifle follow both movement and aim.
 const handX=x+Math.cos(angle)*9-Math.sin(angle)*4;
 const handY=y-16+Math.sin(angle)*8+Math.cos(angle)*3;
 const gunW=76*1.45*1.25,gunH=gunW*(spriteImages["ak47.png"]?.naturalHeight||451)/(spriteImages["ak47.png"]?.naturalWidth||1492);
 const muzzleX=handX+Math.cos(angle)*gunW*.66;
 const muzzleY=handY+Math.sin(angle)*gunW*.66;
 return {handX,handY,gunW,gunH,muzzleX,muzzleY};
}
function drawPlayerSprite(x,y,angle){
 const moving=playerRunTime>0;
 const frame=Math.floor(playerRunTime*9)%3+1;
 const file=!moving?"idle.png":(playerFacing<0?"run_left_":"run_right_")+frame+".png";
 const img=spriteImages[file],weapon=spriteImages["ak47.png"];
 if(img&&img.complete&&img.naturalWidth){
  const h=82*1.45*1.25,w=h*img.naturalWidth/img.naturalHeight;
  ctx.save();ctx.imageSmoothingEnabled=false;ctx.drawImage(img,Math.round(x-w/2),Math.round(y-h/2),Math.round(w),Math.round(h));ctx.restore();
 }else drawPixelCharacter(x,y,angle);
 if(weapon&&weapon.complete&&weapon.naturalWidth){
  const pose=getWeaponPose(x,y,angle);
  const pointsLeft=Math.cos(angle)<0;
  ctx.save();ctx.translate(pose.handX,pose.handY);ctx.rotate(angle);
  // Flip only the rifle's vertical axis on the left-facing half-plane so the
  // magazine remains below the receiver instead of appearing upside down.
  if(pointsLeft)ctx.scale(1,-1);
  ctx.imageSmoothingEnabled=false;
  // Grip is placed exactly at the hand pivot; stock trails the hand, muzzle leads.
  ctx.drawImage(weapon,-pose.gunW*.31,-pose.gunH*.70,pose.gunW,pose.gunH);
  ctx.restore();
 }
}
function pixelRect(x,y,w,h,color){ctx.fillStyle=color;ctx.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h))}
function drawPixelAK(x,y,angle){
 ctx.save();ctx.translate(x,y);ctx.rotate(angle);ctx.scale(1.25,1.25);
 // compact AK silhouette, chunky pixel edges
 pixelRect(-2,-3,23,6,"#17131b");pixelRect(1,-2,18,4,"#6e5550");
 pixelRect(5,-5,8,10,"#a87958");pixelRect(13,-4,5,8,"#493b43");
 pixelRect(18,-2,11,4,"#b9bec8");pixelRect(26,-3,5,6,"#17131b");
 pixelRect(-7,-2,7,4,"#e58a39");pixelRect(-9,-3,3,6,"#17131b");
 pixelRect(3,3,5,7,"#b87945");pixelRect(2,8,7,2,"#17131b");
 pixelRect(10,3,3,3,"#25202b");pixelRect(16,3,4,2,"#25202b");
 ctx.restore();
}
function drawPixelCharacter(x,y,angle){
 const s=1.15;ctx.save();ctx.translate(Math.round(x),Math.round(y));ctx.scale(s,s);
 // feet and dark boots
 pixelRect(-8,10,6,5,"#17131b");pixelRect(3,10,6,5,"#17131b");
 pixelRect(-7,11,4,2,"#d94a3e");pixelRect(4,11,4,2,"#d94a3e");
 // legs and jacket: modest dark outfit
 pixelRect(-7,3,14,8,"#242238");pixelRect(-5,4,10,5,"#34334b");
 pixelRect(-8,-3,16,9,"#111a2b");pixelRect(-3,-2,6,5,"#b52f38");
 pixelRect(-10,-2,4,8,"#a7dfc7");pixelRect(6,-2,4,8,"#a7dfc7");
 pixelRect(-9,4,3,4,"#e9c5b2");pixelRect(6,4,3,4,"#e9c5b2");
 // face
 pixelRect(-5,-14,10,10,"#f2cbb7");pixelRect(-6,-12,2,6,"#e5a995");
 pixelRect(-4,-11,2,1,"#e8c65c");pixelRect(2,-11,2,1,"#e8c65c");
 pixelRect(-2,-8,4,1,"#a95f60");
 // long mint-green hair and pink/lilac accent fringe
 pixelRect(-7,-18,14,5,"#6cbd9b");pixelRect(-8,-15,3,10,"#62b68f");
 pixelRect(5,-15,3,12,"#83d2b0");pixelRect(-6,-19,12,3,"#b5ead5");
 pixelRect(-5,-14,3,5,"#9bd8c3");pixelRect(-2,-14,3,4,"#d7a0d1");
 pixelRect(1,-14,3,5,"#7cc6a4");pixelRect(4,-13,2,4,"#d7a0d1");
 // collar and tiny cyan details
 pixelRect(-3,-3,6,2,"#e64b53");pixelRect(-1,0,2,3,"#00eaff");
 ctx.restore();
 drawPixelAK(x+Math.cos(angle)*12,y+Math.sin(angle)*12,angle);
}
function circle(x,y,r,color,glow=0){r*=1.45;glow*=1.25;ctx.fillStyle=color;if(glow){ctx.shadowBlur=glow;ctx.shadowColor=color}ctx.beginPath();ctx.arc(x,y,r,0,TAU);ctx.fill();ctx.shadowBlur=0}
function draw(){
 ctx.fillStyle="#03070d";ctx.fillRect(0,0,W,H);
 ctx.strokeStyle="rgba(0,220,255,.055)";ctx.lineWidth=1;const grid=42;for(let x=0;x<W;x+=grid){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke()}for(let y=0;y<H;y+=grid){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke()}
 ctx.save();if(shake)ctx.translate(rand(-shake,shake),rand(-shake,shake));
 for(const p of particles){ctx.globalAlpha=clamp(p.life/p.max,.0,1);circle(p.x,p.y,p.r,p.color,8)}ctx.globalAlpha=1;
 for(const p of drops){
  const dropImg=p.type==="potion"?spriteImages["pizza.png"]:spriteImages["token_f.png"];
  const size=(p.type==="potion"?27:25)*1.45*1.30;
  if(dropImg&&dropImg.complete&&dropImg.naturalWidth){
   ctx.save();ctx.imageSmoothingEnabled=false;ctx.shadowColor=p.type==="potion"?"#39ff91":"#ffcf35";ctx.shadowBlur=13;
   ctx.drawImage(dropImg,Math.round(p.x-size/2),Math.round(p.y-size/2),size,size);ctx.restore();
  }else if(p.type==="potion"){circle(p.x,p.y,p.r,"#39ff91",15);ctx.fillStyle="#07351f";ctx.fillRect(p.x-2,p.y-6,4,12);ctx.fillRect(p.x-6,p.y-2,12,4)}
  else{circle(p.x,p.y,p.r,"#ffcf35",14);ctx.fillStyle="#001";ctx.font="bold 12px monospace";ctx.textAlign="center";ctx.fillText("$",p.x,p.y+4)}
 }
 for(const b of bullets){
  const pencil=spriteImages["bullet_pencil.png"];
  if(pencil&&pencil.complete&&pencil.naturalWidth){
   const a=Math.atan2(b.vy,b.vx);
   ctx.save();ctx.translate(b.x,b.y);ctx.rotate(a-Math.PI*.75);ctx.imageSmoothingEnabled=false;
   ctx.drawImage(pencil,-18.75,-18.75,37.5,37.5);ctx.restore();
  }else circle(b.x,b.y,b.r,"#ffbd55",12);
 }
 for(const b of enemyShots)circle(b.x,b.y,b.r,"#ff35dd",13);
 for(const t of bossTelegraphs){
  ctx.save();ctx.globalAlpha=.38+.42*Math.sin(time*28);ctx.strokeStyle="#fff2a8";ctx.shadowColor="#ffe66d";ctx.shadowBlur=14;ctx.lineWidth=3;ctx.setLineDash([12,9]);
  if(t.mode==="sweep"){
   const count=t.rayCount||7;
   for(let k=0;k<count;k++){const a=t.angle+k*TAU/count;ctx.beginPath();ctx.moveTo(t.x,t.y);ctx.lineTo(t.x+Math.cos(a)*t.length,t.y+Math.sin(a)*t.length);ctx.stroke()}
   const sweepDuration=t.duration||(boss&&boss.stage===2?2:Math.max(2.5,(Math.PI*260)/(player.speed*.75)));
   const sweepSpeed=t.angularSpeed||(boss&&boss.stage===2?(player.speed*.45/260):(Math.PI/sweepDuration));
   const sweepAngle=sweepSpeed*sweepDuration;
   const end=t.angle+t.dir*sweepAngle,ex=t.x+Math.cos(end)*92,ey=t.y+Math.sin(end)*92;
   ctx.setLineDash([]);ctx.lineWidth=5;ctx.beginPath();ctx.arc(t.x,t.y,92,t.angle,end,t.dir<0);ctx.stroke();
   ctx.fillStyle="#fff2a8";ctx.font="bold 16px monospace";ctx.textAlign="center";ctx.fillText((t.dir>0?"↻ ":"↺ ")+Math.round(sweepAngle*180/Math.PI)+"°",t.x,t.y-112);
   ctx.beginPath();ctx.arc(ex,ey,6,0,TAU);ctx.fill();
  }else{ctx.beginPath();ctx.moveTo(t.x,t.y);ctx.lineTo(t.x+Math.cos(t.angle)*t.length,t.y+Math.sin(t.angle)*t.length);ctx.stroke()}
  ctx.setLineDash([]);ctx.restore();
 }
 for(const l of bossLasers){ctx.save();ctx.globalAlpha=clamp(l.life/l.maxLife,0,1);ctx.strokeStyle="#ff42e8";ctx.shadowColor="#ff26d8";ctx.shadowBlur=22;ctx.lineWidth=l.width;ctx.beginPath();ctx.moveTo(l.x,l.y);ctx.lineTo(l.x+Math.cos(l.angle)*l.length,l.y+Math.sin(l.angle)*l.length);ctx.stroke();ctx.strokeStyle="#fff";ctx.lineWidth=2;ctx.stroke();ctx.restore()}
 for(const e of foes){circle(e.x,e.y,e.r,e.color,13);ctx.fillStyle="rgba(0,0,0,.65)";ctx.fillRect(e.x-e.r*1.45,e.y-e.r*1.45-11,e.r*2*1.45,4);ctx.fillStyle="#7cffae";ctx.fillRect(e.x-e.r*1.45,e.y-e.r*1.45-11,e.r*2*1.45*clamp(e.hp/e.maxHp,0,1),4)}
 if(boss){circle(boss.x,boss.y,boss.r*1.35,"rgba(255,30,220,.18)",20);circle(boss.x,boss.y,boss.r,boss.color,24);circle(boss.x,boss.y,boss.r*.43,"#fff",12)}
 if(!gameOver){ctx.globalAlpha=player.invuln>0&&Math.floor(time*18)%2?.35:1;drawPlayerSprite(player.x,player.y,aimAngle);ctx.globalAlpha=1}
 ctx.restore();
 if(input.mouseInside&&!gameOver){ctx.strokeStyle="rgba(0,235,255,.9)";ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(input.mouseX,input.mouseY,9,0,TAU);ctx.moveTo(input.mouseX-15,input.mouseY);ctx.lineTo(input.mouseX-5,input.mouseY);ctx.moveTo(input.mouseX+5,input.mouseY);ctx.lineTo(input.mouseX+15,input.mouseY);ctx.moveTo(input.mouseX,input.mouseY-15);ctx.lineTo(input.mouseX,input.mouseY-5);ctx.moveTo(input.mouseX,input.mouseY+5);ctx.lineTo(input.mouseX,input.mouseY+15);ctx.stroke()}
 const scale=Math.min(1.35,W/340)*1.3;ctx.textAlign="left";ctx.textBaseline="top";ctx.font=`bold ${19*scale}px monospace`;ctx.fillStyle="#fff";ctx.fillText("SCORE "+score,14,14);ctx.fillStyle="#ffbd55";ctx.font=`bold ${14*scale}px monospace`;ctx.fillText("BEST "+best,14,36);ctx.fillStyle="#00eaff";ctx.font=`bold ${18*scale}px monospace`;ctx.fillText(bossWave?"BOSS WAVE "+bossNumber:"WAVE "+wave,14,55);
 ctx.textAlign="right";ctx.fillStyle="#6e9bad";ctx.font=`bold ${10*scale}px monospace`;ctx.fillText(GAME_VERSION,W-14,16);
 ctx.textAlign="center";ctx.fillStyle="#00eaff";ctx.font=`bold ${24*scale}px monospace`;ctx.fillText(fmt(time),W/2,14);ctx.font=`bold ${10*scale}px monospace`;ctx.fillStyle="#7adfff";ctx.fillText("SURVIVAL",W/2,42);
 const bw=Math.min(250,W*.58)*1.3,bh=26,bx=16,by=H-42;ctx.fillStyle="#29323d";ctx.fillRect(bx,by,bw,bh);ctx.fillStyle=player.hp>55?"#39ff87":player.hp>25?"#ffe45c":"#ff3c5c";ctx.fillRect(bx,by,bw*clamp(player.hp/player.maxHp,0,1),bh);ctx.strokeStyle="#fff";ctx.strokeRect(bx,by,bw,bh);ctx.fillStyle="#fff";ctx.font="bold 17px monospace";ctx.textAlign="left";ctx.fillText("HP "+Math.ceil(player.hp)+"/"+Math.ceil(player.maxHp),bx+7,by+2);
 ctx.fillStyle="#ffbd55";ctx.font=`bold ${14*scale}px monospace`;ctx.fillText(weapons[currentWeapon].name,14,H-48);ctx.fillStyle="#ffe45c";ctx.font=`bold ${15*scale}px monospace`;ctx.fillText("COINS "+coins,14,91);
 if(boss){const w=Math.min(W-36,360*1.3),x=(W-w)/2,y=88;ctx.fillStyle="#281027";ctx.fillRect(x,y,w,13);ctx.fillStyle="#ff26d8";ctx.fillRect(x,y,w*clamp(boss.hp/boss.maxHp,0,1),13);ctx.strokeStyle="#fff";ctx.strokeRect(x,y,w,13);ctx.textAlign="center";ctx.fillStyle="#ff9cf0";ctx.font="bold 13px monospace";ctx.fillText("BOSS "+bossNumber+" · PHASE "+boss.stage,W/2,y-14)}
 if(waveBannerTimer>0&&!gameOver&&!shopOpen){
  const alpha=clamp(Math.min(waveBannerTimer*2,1),0,1);
  ctx.save();ctx.globalAlpha=alpha;ctx.textAlign="center";ctx.textBaseline="middle";
  ctx.font=`bold ${Math.min(25,W/19)}px monospace`;ctx.shadowColor="#00eaff";ctx.shadowBlur=18;
  ctx.fillStyle=bossWave?"#ff72e9":"#8ffaff";ctx.fillText(waveBanner,W/2,H*.34);ctx.restore();
 }
 if(paused&&!shopOpen&&!gameOver){ctx.fillStyle="rgba(0,0,0,.68)";ctx.fillRect(0,0,W,H);ctx.textAlign="center";ctx.textBaseline="middle";ctx.fillStyle="#00eaff";ctx.font=`bold ${Math.min(38,W/10)}px monospace`;ctx.fillText("PAUSED",W/2,H/2);ctx.fillStyle="#fff";ctx.font="15px monospace";ctx.fillText("PRESS P OR CLICK RESUME",W/2,H/2+42)}
 if(gameOver){ctx.fillStyle="rgba(0,0,0,.78)";ctx.fillRect(0,0,W,H);ctx.textAlign="center";ctx.textBaseline="middle";ctx.fillStyle="#ff426c";ctx.font=`bold ${Math.min(38,W/10)}px monospace`;ctx.fillText("GAME OVER",W/2,H/2-90);ctx.fillStyle="#00eaff";ctx.font=`bold ${Math.min(25,W/15)}px monospace`;ctx.fillText("TIME "+fmt(time),W/2,H/2-45);ctx.fillStyle="#fff";ctx.font=`bold ${Math.min(22,W/18)}px monospace`;ctx.fillText("SCORE "+score,W/2,H/2);ctx.fillStyle="#ffbd55";ctx.font=`bold ${Math.min(15,W/24)}px monospace`;ctx.fillText("BEST "+best+"  •  RECORD TIME "+fmt(bestTime),W/2,H/2+40);ctx.fillStyle="#00eaff";ctx.font=`bold ${Math.min(17,W/21)}px monospace`;ctx.fillText("CLICK OR PRESS R TO RESTART",W/2,H/2+100)}
}
function fmt(s){let m=Math.floor(s/60),v=Math.floor(s%60);return String(m).padStart(2,"0")+":"+String(v).padStart(2,"0")}
beginWave();
function loop(now){const dt=Math.min(.033,(now-last)/1000||0);last=now;update(dt);draw();requestAnimationFrame(loop)}
requestAnimationFrame(loop);
document.addEventListener("visibilitychange",()=>{last=performance.now();input.keys.clear();input.shooting=false});
})();
